# SlideMenu
A simple Menu inspired by SWRevealView Controller and Google Material Menu
